const { getDb } = require('../database/connection');

function createUser({
  username,
  email,
  displayName,
  passwordHash,
  role = 'user',
}) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      'INSERT INTO users (username, email, display_name, password_hash, role) VALUES (?, ?, ?, ?, ?)'
    );
    stmt.run(username, email, displayName, passwordHash, role, function (err) {
      if (err) {
        reject(err);
      } else {
        resolve({
          id: this.lastID,
          username,
          email,
          display_name: displayName,
          role,
        });
      }
    });
  });
}

function findUserByUsername(username) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM users WHERE username = ?', [username], (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row || null);
      }
    });
  });
}

function findUserById(id) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM users WHERE id = ?', [id], (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row || null);
      }
    });
  });
}

function incrementFailedAttempts(userId) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      `UPDATE users
       SET failed_attempts = failed_attempts + 1,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    );
    stmt.run(userId, function (err) {
      if (err) return reject(err);
      return resolve();
    });
  });
}

function setLockUntil(userId, lockUntil) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      `UPDATE users
       SET lock_until = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    );
    stmt.run(lockUntil, userId, function (err) {
      if (err) return reject(err);
      return resolve();
    });
  });
}

function resetLoginStateAndRecordSuccess(userId, ip) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      `UPDATE users
       SET failed_attempts = 0,
           lock_until = NULL,
           last_login_at = CURRENT_TIMESTAMP,
           last_login_ip = ?,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    );
    stmt.run(ip, userId, function (err) {
      if (err) return reject(err);
      return resolve();
    });
  });
}

function setUserActiveState(userId, isActive) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      `UPDATE users
       SET is_active = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    );
    stmt.run(isActive ? 1 : 0, userId, function (err) {
      if (err) return reject(err);
      return resolve();
    });
  });
}

function getAllUsers() {
  const db = getDb();
  return new Promise((resolve, reject) => {
    db.all(
      'SELECT id, username, email, display_name, role, is_active, failed_attempts, lock_until, created_at FROM users ORDER BY created_at DESC',
      (err, rows) => {
        if (err) return reject(err);
        return resolve(rows || []);
      }
    );
  });
}

function toggleUserRole(userId) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      `UPDATE users
       SET role = CASE WHEN role = 'admin' THEN 'user' ELSE 'admin' END,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    );
    stmt.run(userId, function (err) {
      if (err) return reject(err);
      return resolve();
    });
  });
}

module.exports = {
  createUser,
  findUserByUsername,
  findUserById,
  incrementFailedAttempts,
  setLockUntil,
  resetLoginStateAndRecordSuccess,
  setUserActiveState,
  getAllUsers,
  toggleUserRole,
};


