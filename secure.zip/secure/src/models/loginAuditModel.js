const { getDb } = require('../database/connection');

function recordLoginAttempt({ userId, username, ip, userAgent, success }) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    const stmt = db.prepare(
      'INSERT INTO login_audit (user_id, username, ip, user_agent, success) VALUES (?, ?, ?, ?, ?)'
    );
    stmt.run(userId || null, username || null, ip, userAgent, success ? 1 : 0, (err) => {
      if (err) return reject(err);
      return resolve();
    });
  });
}

function getRecentLoginActivity(userId, limit = 10) {
  const db = getDb();
  return new Promise((resolve, reject) => {
    db.all(
      'SELECT * FROM login_audit WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
      [userId, limit],
      (err, rows) => {
        if (err) return reject(err);
        return resolve(rows || []);
      }
    );
  });
}

module.exports = {
  recordLoginAttempt,
  getRecentLoginActivity,
};



