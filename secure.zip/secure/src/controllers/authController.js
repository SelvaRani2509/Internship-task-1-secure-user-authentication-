const { validationResult } = require('express-validator');
const { hashPassword, comparePassword } = require('../config/password');
const {
  createUser,
  findUserByUsername,
  incrementFailedAttempts,
  setLockUntil,
  resetLoginStateAndRecordSuccess,
} = require('../models/userModel');
const { recordLoginAttempt } = require('../models/loginAuditModel');

// Security configuration (could be moved to a config file)
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

async function getLogin(req, res) {
  return res.render('auth/login', { errors: [], old: {} });
}

async function postLogin(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('auth/login', {
      errors: errors.array(),
      old: req.body,
    });
  }

  const { username, password } = req.body;
  const ip = req.ip;
  const userAgent = req.get('user-agent') || '';

  try {
    const user = await findUserByUsername(username.toLowerCase());

    if (!user) {
      // Unknown user - still record audit with null userId
      await recordLoginAttempt({
        userId: null,
        username,
        ip,
        userAgent,
        success: false,
      });

      return res.status(400).render('auth/login', {
        errors: [{ msg: 'Invalid credentials' }],
        old: { username },
      });
    }

    // Check if account is active
    if (!user.is_active) {
      await recordLoginAttempt({
        userId: user.id,
        username: user.username,
        ip,
        userAgent,
        success: false,
      });

      return res.status(403).render('auth/login', {
        errors: [{ msg: 'Account is inactive. Please contact support.' }],
        old: { username },
      });
    }

    // Check for lockout
    if (user.lock_until) {
      const lockUntil = new Date(user.lock_until);
      if (lockUntil > new Date()) {
        await recordLoginAttempt({
          userId: user.id,
          username: user.username,
          ip,
          userAgent,
          success: false,
        });

        return res.status(403).render('auth/login', {
          errors: [
            {
              msg: 'Account is locked due to multiple failed login attempts. Please try again later.',
            },
          ],
          old: { username },
        });
      }
    }

    const match = await comparePassword(password, user.password_hash);
    if (!match) {
      await incrementFailedAttempts(user.id);

      // If failed attempts exceed threshold, set lock_until
      const updatedUser = await findUserByUsername(username.toLowerCase());
      if (updatedUser.failed_attempts >= MAX_FAILED_ATTEMPTS) {
        const lockUntil = new Date();
        lockUntil.setMinutes(lockUntil.getMinutes() + LOCKOUT_MINUTES);
        await setLockUntil(updatedUser.id, lockUntil.toISOString());
      }

      await recordLoginAttempt({
        userId: user.id,
        username: user.username,
        ip,
        userAgent,
        success: false,
      });

      return res.status(400).render('auth/login', {
        errors: [{ msg: 'Invalid credentials' }],
        old: { username },
      });
    }

    // Successful login: reset counters and record success
    await resetLoginStateAndRecordSuccess(user.id, ip);
    await recordLoginAttempt({
      userId: user.id,
      username: user.username,
      ip,
      userAgent,
      success: true,
    });

    req.session.user = {
      id: user.id,
      username: user.username,
      role: user.role,
    };

    // Flash message
    req.session.flash = { type: 'success', message: 'Logged in successfully.' };

    return res.redirect('/app/dashboard');
  } catch (err) {
    return next(err);
  }
}

async function getRegister(req, res) {
  return res.render('auth/register', { errors: [], old: {} });
}

async function postRegister(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).render('auth/register', {
      errors: errors.array(),
      old: req.body,
    });
  }

  const { username, email, displayName, password } = req.body;

  try {
    const existing = await findUserByUsername(username.toLowerCase());
    if (existing) {
      return res.status(400).render('auth/register', {
        errors: [{ msg: 'Username already in use' }],
        old: { username, email, displayName },
      });
    }

    const passwordHash = await hashPassword(password);
    const user = await createUser({
      username: username.toLowerCase(),
      email: email.toLowerCase(),
      displayName: displayName || null,
      passwordHash,
      role: 'user',
    });

    req.session.user = {
      id: user.id,
      username: user.username,
      role: user.role,
    };

    req.session.flash = {
      type: 'success',
      message: 'Account created successfully. You are now logged in.',
    };

    return res.redirect('/app/dashboard');
  } catch (err) {
    if (err && err.code === 'SQLITE_CONSTRAINT') {
      return res.status(400).render('auth/register', {
        errors: [{ msg: 'Username or email already in use' }],
        old: { username, email, displayName },
      });
    }
    return next(err);
  }
}

function postLogout(req, res, next) {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('sid');
    return res.redirect('/');
  });
}

module.exports = {
  getLogin,
  postLogin,
  getRegister,
  postRegister,
  postLogout,
};


