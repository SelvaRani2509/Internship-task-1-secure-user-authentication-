const {
  findUserById,
  getAllUsers,
  setUserActiveState,
  toggleUserRole,
} = require('../models/userModel');
const { getRecentLoginActivity } = require('../models/loginAuditModel');

async function getDashboard(req, res, next) {
  try {
    const userId = req.session.user.id;
    const user = await findUserById(userId);
    const activity = await getRecentLoginActivity(userId, 5);

    return res.render('app/dashboard', {
      profile: user,
      activity,
    });
  } catch (err) {
    return next(err);
  }
}

async function getAdmin(req, res) {
  const users = await getAllUsers();
  return res.render('app/admin', { users });
}

async function postToggleActive(req, res, next) {
  try {
    const userId = Number(req.params.id);
    if (Number.isNaN(userId)) {
      req.session.flash = { type: 'error', message: 'Invalid user id.' };
      return res.redirect('/app/admin');
    }

    await setUserActiveState(userId, req.body.isActive === 'true');
    req.session.flash = { type: 'success', message: 'User active state updated.' };
    return res.redirect('/app/admin');
  } catch (err) {
    return next(err);
  }
}

async function postToggleRole(req, res, next) {
  try {
    const userId = Number(req.params.id);
    if (Number.isNaN(userId)) {
      req.session.flash = { type: 'error', message: 'Invalid user id.' };
      return res.redirect('/app/admin');
    }

    await toggleUserRole(userId);
    req.session.flash = { type: 'success', message: 'User role updated.' };
    return res.redirect('/app/admin');
  } catch (err) {
    return next(err);
  }
}

module.exports = {
  getDashboard,
  getAdmin,
  postToggleActive,
  postToggleRole,
};


