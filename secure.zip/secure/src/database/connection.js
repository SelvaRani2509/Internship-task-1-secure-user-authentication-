const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const DB_PATH = path.join(__dirname, '..', '..', 'data', 'app.sqlite');

let dbInstance;

function getDb() {
  if (!dbInstance) {
    dbInstance = new sqlite3.Database(DB_PATH);
  }
  return dbInstance;
}

function initDb() {
  return new Promise((resolve, reject) => {
    const db = getDb();

    db.serialize(() => {
      // Users table - professional schema
      db.run(
        `
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          email TEXT NOT NULL UNIQUE,
          display_name TEXT,
          password_hash TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'user',
          failed_attempts INTEGER NOT NULL DEFAULT 0,
          lock_until DATETIME,
          last_login_at DATETIME,
          last_login_ip TEXT,
          is_active INTEGER NOT NULL DEFAULT 1,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        `
      );

      // Login audit table
      db.run(
        `
        CREATE TABLE IF NOT EXISTS login_audit (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          username TEXT,
          ip TEXT,
          user_agent TEXT,
          success INTEGER NOT NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id)
        );
        `
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);`
      );
      db.run(`CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);`);

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_login_audit_user_id ON login_audit(user_id);`
      );

      db.get('SELECT 1', (err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  });
}

module.exports = {
  getDb,
  initDb,
};


