function notFoundHandler(req, res, next) {
  res.status(404);
  if (req.accepts('html')) {
    return res.render('404');
  }
  if (req.accepts('json')) {
    return res.json({ error: 'Not found' });
  }
  return res.type('txt').send('Not found');
}

// Central error handler
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error(err);
  const status = err.status || 500;
  const message = status === 500 ? 'Internal server error' : err.message;

  if (req.accepts('html')) {
    return res.status(status).render('error', { status, message });
  }

  if (req.accepts('json')) {
    return res.status(status).json({ error: message });
  }

  return res.status(status).type('txt').send(message);
}

module.exports = {
  notFoundHandler,
  errorHandler,
};



