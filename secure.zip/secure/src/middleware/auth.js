// Centralized authentication & authorization middleware

function requireAuth(req, res, next) {
  if (req.session && req.session.user) {
    return next();
  }
  return res.redirect('/auth/login');
}

function requireGuest(req, res, next) {
  if (req.session && req.session.user) {
    return res.redirect('/app/dashboard');
  }
  next();
}

function requireRole(role) {
  return function (req, res, next) {
    if (!req.session || !req.session.user) {
      return res.redirect('/auth/login');
    }
    if (req.session.user.role !== role) {
      return res.status(403).render('403');
    }
    next();
  };
}

module.exports = {
  requireAuth,
  requireGuest,
  requireRole,
};



