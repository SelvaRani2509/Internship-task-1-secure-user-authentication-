const express = require('express');
const { requireAuth, requireRole } = require('../middleware/auth');
const {
  getDashboard,
  getAdmin,
  postToggleActive,
  postToggleRole,
} = require('../controllers/appController');

const router = express.Router();

router.get('/dashboard', requireAuth, getDashboard);

router.get('/admin', requireRole('admin'), getAdmin);
router.post('/admin/users/:id/toggle-active', requireRole('admin'), postToggleActive);
router.post('/admin/users/:id/toggle-role', requireRole('admin'), postToggleRole);

module.exports = router;



