const express = require('express');
const { body } = require('express-validator');
const { requireGuest } = require('../middleware/auth');
const {
  getLogin,
  postLogin,
  getRegister,
  postRegister,
  postLogout,
} = require('../controllers/authController');

const router = express.Router();

router.get('/login', requireGuest, getLogin);

router.post(
  '/login',
  requireGuest,
  [
    body('username')
      .trim()
      .isLength({ min: 3 })
      .withMessage('Username is required'),
    body('password').isLength({ min: 6 }).withMessage('Password is required'),
  ],
  postLogin
);

router.get('/register', requireGuest, getRegister);

router.post(
  '/register',
  requireGuest,
  [
    body('username')
      .trim()
      .isLength({ min: 3 })
      .withMessage('Username must be at least 3 characters long'),
    body('email')
      .isEmail()
      .withMessage('Valid email is required')
      .normalizeEmail(),
    body('displayName').optional().trim().isLength({ max: 100 }),
    body('password')
      .isLength({ min: 8 })
      .withMessage('Password must be at least 8 characters long'),
    body('confirmPassword').custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Passwords do not match');
      }
      return true;
    }),
  ],
  postRegister
);

router.post('/logout', postLogout);

module.exports = router;



