require('dotenv').config();

const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const path = require('path');
const helmet = require('helmet');
const morgan = require('morgan');
const csrf = require('csurf');

const { initDb } = require('./src/database/connection');
const authRoutes = require('./src/routes/authRoutes');
const protectedRoutes = require('./src/routes/protectedRoutes');
const { errorHandler, notFoundHandler } = require('./src/middleware/errorHandler');

const app = express();

const NODE_ENV = process.env.NODE_ENV || 'development';
const isProduction = NODE_ENV === 'production';

if (isProduction && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  // Fail fast in production if SESSION_SECRET is weak or missing
  throw new Error('SESSION_SECRET must be set to a strong value in production.');
}

if (isProduction) {
  // when behind a proxy (e.g. Heroku, Render, Nginx), trust the first proxy so secure cookies work
  app.set('trust proxy', 1);
}

// --- Security & parsing middleware ---
app.use(
  helmet({
    contentSecurityPolicy: false, // can be tuned later
  })
);
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(morgan('dev'));

// --- Static assets & views ---
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src', 'views'));
app.use(express.static(path.join(__dirname, 'src', 'public')));

// --- Session configuration ---
const sessionSecret = process.env.SESSION_SECRET || 'change-this-in-dev-only';

app.use(
  session({
    store: new SQLiteStore({
      db: 'sessions.sqlite',
      dir: path.join(__dirname, 'data'),
    }),
    name: 'sid',
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: isProduction, // only send cookie over HTTPS in production
      sameSite: isProduction ? 'lax' : 'lax',
      maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
    },
  })
);

// --- CSRF protection for form-based routes ---
const csrfProtection = csrf();
app.use(csrfProtection);

// Expose CSRF token, user info, and flash messages to templates
app.use((req, res, next) => {
  res.locals.csrfToken = req.csrfToken();
  res.locals.currentUser = req.session.user || null;
  res.locals.flash = req.session.flash || null;
  if (req.session.flash) {
    delete req.session.flash;
  }
  next();
});

// --- Routes ---
app.get('/', (req, res) => {
  res.render('home');
});

app.use('/auth', authRoutes);
app.use('/app', protectedRoutes);

// Session / health endpoints
app.get('/whoami', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ authenticated: false });
  }
  return res.json({
    authenticated: true,
    user: req.session.user,
  });
});

app.get('/health', (req, res) => {
  return res.json({ status: 'ok' });
});

// 404 and error handling
app.use(notFoundHandler);
app.use(errorHandler);

const PORT = process.env.PORT || 3000;

initDb()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Failed to initialize database', err);
    process.exit(1);
  });


