// Usage:
//   node scripts/makeAdmin.js your_username
//
// This is a small helper script to promote a user to admin without needing
// the sqlite3 CLI installed. It reuses the existing database connection.

const { getDb } = require('../src/database/connection');

async function main() {
  const username = process.argv[2];

  if (!username) {
    console.error('Please provide a username:\n  node scripts/makeAdmin.js your_username');
    process.exit(1);
  }

  const db = getDb();

  db.serialize(() => {
    db.get(
      'SELECT id, username, role FROM users WHERE username = ?',
      [username.toLowerCase()],
      (err, row) => {
        if (err) {
          console.error('Error fetching user:', err);
          process.exit(1);
        }

        if (!row) {
          console.error(`No user found with username "${username}"`);
          process.exit(1);
        }

        db.run(
          `UPDATE users SET role = 'admin', updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
          [row.id],
          (updateErr) => {
            if (updateErr) {
              console.error('Error updating user role:', updateErr);
              process.exit(1);
            }

            console.log(
              `User "${row.username}" (id=${row.id}) role updated from "${row.role}" to "admin".`
            );
            process.exit(0);
          }
        );
      }
    );
  });
}

main();


