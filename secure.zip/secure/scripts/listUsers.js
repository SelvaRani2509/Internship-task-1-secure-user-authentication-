// Lists all users with their id, username, email, and role.
// Usage:
//   node scripts/listUsers.js

const { getDb } = require('../src/database/connection');

const db = getDb();

db.all(
  'SELECT id, username, email, role, is_active FROM users ORDER BY created_at DESC',
  (err, rows) => {
    if (err) {
      console.error('Error reading users:', err);
      process.exit(1);
    }
    if (!rows || !rows.length) {
      console.log('No users found.');
      process.exit(0);
    }
    console.table(rows);
    process.exit(0);
  }
);


